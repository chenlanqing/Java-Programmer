// JavaScript Document
/*
封装获取DOM节点的方法
*/
var doc = document;

function getById(id){
	return doc.getElementById(id);
}

function getByName(name){
	return doc.getElementsByName(name);
}
	
function getByTagName(tagName){
	return doc.getElementsByTagName(tagName);
}

function createEle(tag){
	return doc.createElement("table");
}