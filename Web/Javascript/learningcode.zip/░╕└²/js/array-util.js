// JavaScript Document
//该js文件往Array对象中添加自定义方法
/*
	找出数组中最大值
*/
function getMax(){
	var max = this[0];
	for(var x=1;x<this.length;x++){
		if(max<this[x])
			max = this[x];
	}
	return max;
}
/*
	找出数组中最大值
*/
function getMin(){
	var min = 0;
	for(var x=1;x<this.length;x++){
		if(this[min]<this[x])
			min = x;
	}
	return this[min];
}

//将上述方法封装到对象中
Array.prototype.getMax = getMax;
Array.prototype.getMin = getMin;






